"""Outside-repository proof that a keeper closes on controlled failure/interrupt."""
import importlib.util
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest
from unittest import mock

HERE=Path(__file__).resolve().parent
ROOT=Path('/private/tmp/cobol-global-formula-audit-tree-20261110')
sys.path[:0]=[str(ROOT/'poc'),str(ROOT/'poc/tests')]
spec=importlib.util.spec_from_file_location('keeper_diagnostic', HERE/'diagnose_online_inventory_cost.py')
diagnostic=importlib.util.module_from_spec(spec);spec.loader.exec_module(diagnostic)
import large_repository_online_driver as driver
import online_inventory_store as inventory
import online_investigation as investigation

class KeeperCleanupTests(unittest.TestCase):
    def check_failure(self, failure):
        with tempfile.TemporaryDirectory() as temporary:
            output=Path(temporary)/'observations';output.mkdir()
            observer=diagnostic.Observer(output,'cleanup-only',journal_mode='WAL')
            real_connect=sqlite3.connect
            keepers=[]
            def connect(*args,**options):
                db=real_connect(*args,**options)
                if str(args[0]).endswith('online-inventories.sqlite') and 'factory' not in options:
                    keepers.append(db)
                return db
            with mock.patch('sqlite3.connect',side_effect=connect):
                with self.assertRaises(type(failure)):
                    with diagnostic.instrument(observer,driver,inventory,investigation):
                        inventory.OnlineInventoryStore(Path(temporary)/'inventory')
                        self.assertEqual(1,len(keepers))
                        self.assertFalse(keepers[0].in_transaction)
                        raise failure
            self.assertEqual(1,observer.counts['keeper_connections_opened'])
            self.assertEqual(1,observer.counts['keeper_connections_closed'])
            self.assertEqual(1,observer.counts['keeper_transaction_free_on_exit'])
            with self.assertRaises(sqlite3.ProgrammingError):
                keepers[0].execute('SELECT 1')
    def test_closes_keeper_on_controlled_failure(self):
        self.check_failure(RuntimeError('controlled experiment failure'))
    def test_closes_keeper_on_keyboard_interrupt_after_open(self):
        self.check_failure(KeyboardInterrupt())

if __name__=='__main__':
    unittest.main()
