"""External observer only; never selects a production journal mode."""
from collections import Counter
import importlib.util
import json
from pathlib import Path
import sqlite3
import sys
import threading
from unittest import mock

HERE = Path(__file__).resolve().parent
REPO = Path('/private/tmp/cobol-global-formula-audit-tree-20261110')
spec = importlib.util.spec_from_file_location('wal_experiment_diagnostic', HERE / 'diagnose_online_inventory_cost.py')
diagnostic = importlib.util.module_from_spec(spec)
spec.loader.exec_module(diagnostic)
count = int(sys.argv[1])
output = HERE / ('smoke-' + str(count))
main_actor = threading.get_ident()
threads = Counter()
original_connect = sqlite3.connect

def audit_connect(*args, **options):
    actor = threading.get_ident()
    threads[str(actor)] += 1
    assert actor == main_actor, 'A second SQLite connection actor appeared in the controlled experiment'
    return original_connect(*args, **options)

try:
    arguments = diagnostic.argparse.Namespace(repo_root=REPO, output=output, files=count)
    with mock.patch.object(diagnostic.argparse.ArgumentParser, 'parse_args', return_value=arguments), mock.patch('sqlite3.connect', side_effect=audit_connect):
        code = diagnostic.main()
    assert code == 0
    report = json.loads((output / 'DIAGNOSTIC-REPORT.json').read_text())
    assert report['status'] == 'completed_diagnostic'
    assert report['mode_sequence'] == ['DELETE', 'WAL', 'TRUNCATE', 'DELETE']
    assert len(threads) == 1
    summary = {'files':count, 'status':report['status'], 'python':sys.version, 'sqlite':sqlite3.sqlite_version,
        'sqlite_connect_calls_by_thread':dict(threads), 'sqlite_main_thread_only':True,
        'heartbeat_review':'Observer.heartbeat calls snapshot only; snapshot writes JSON with fsync/os.replace, not SQLite.',
        'no_separate_checkpoint_thread':True, 'source_unchanged_in_declared_scope':report['source_unchanged_in_declared_scope'],
        'cases':[]}
    for case in report['cases']:
        observation=json.loads((output / f"case-{case['case']:02d}-{case['mode'].lower()}" / 'observations.json').read_text())
        summary['cases'].append({**case, 'sqlite_configuration':observation['sqlite_configuration'], 'counts':observation['counts'], 'seconds_by_operation':observation['seconds']})
    diagnostic.atomic_json(output / 'SMOKE-SUMMARY.json', summary)
except BaseException:
    if output.is_dir():
        diagnostic.atomic_json(output / 'ACTOR-AUDIT.json', {'sqlite_connect_calls_by_thread':dict(threads),'main_actor':str(main_actor),'status':'not_passed'})
    raise
